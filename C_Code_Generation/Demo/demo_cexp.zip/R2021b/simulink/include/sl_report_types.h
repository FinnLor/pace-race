/* Copyright 2016 The MathWorks, Inc. */
#ifndef SL_REPORT_TYPES_H
#define SL_REPORT_TYPES_H

typedef enum {
    BD_ERR_VALUE_NONE,
    BD_ERR_VALUE_WARNING,
    BD_ERR_VALUE_ERROR
} BDErrorValue;

#endif

